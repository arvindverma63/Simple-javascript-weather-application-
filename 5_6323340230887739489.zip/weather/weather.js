const url = 'http://api.weatherapi.com/v1/current.json?key=19a8ccd079084e88aca83228241703&q=kanpur&aqi=no';

var wind = document.getElementById("wind-speed");
var temp = document.getElementById("temp");
var type = document.getElementById("type");
var city = document.getElementById("city");
var time = document.getElementById("time");

fetch(url)
  .then(response => response.json())
  .then(data => {
    wind.textContent = data.current.wind_kph + " kmph";
    temp.textContent = data.current.temp_c + "°C";
    type.textContent = data.current.condition.text;
    city.textContent = data.location.name;
    time.textContent = data.location.localtime;



    var path = `<div>
                <img src="${data.current.condition.icon}"
                  width="100px">
              </div>`;
    document.getElementById('main').innerHTML = path;

  })
  .catch(error => console.error('Error fetching data:', error));
